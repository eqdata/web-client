<?php

/*
|--------------------------------------------------------------------------
| Web Routes
|--------------------------------------------------------------------------
|
| Here is where you can register web routes for your application. These
| routes are loaded by the RouteServiceProvider within a group which
| contains the "web" middleware group. Now create something great!
|
*/

Route::get('/', function () {
    return View::make('pages.home')->with('index', true);
});
Route::get('/{path?}', function($path = null){
    return View::make('pages.base')->with('showNavSearch', 1);
})->where('path', '.*');
