***Web Front-end***
Public web application for consuming EQ Data API
