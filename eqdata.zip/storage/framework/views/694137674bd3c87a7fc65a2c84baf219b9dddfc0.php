<?php $__env->startSection('content'); ?>
    <!-- Blog Entries Column -->

    <div id="content-container" class="col-xs-12 col-sm-9 col-md-9">
        <div class="pushdown"></div>
        <div class="loader"></div>
    </div>

    <!-- Blog Sidebar Widgets Column -->
    <div id="sidebar-container" class="sidebar-container col-xs-12 col-sm-3 col-md-3">
        <?php echo $__env->make('includes.sidebar', array_except(get_defined_vars(), array('__data', '__path')))->render(); ?>
    </div>
<?php $__env->stopSection(); ?>
<?php echo $__env->make('layouts.default', array_except(get_defined_vars(), array('__data', '__path')))->render(); ?>